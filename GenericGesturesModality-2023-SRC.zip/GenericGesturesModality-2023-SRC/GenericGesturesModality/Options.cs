﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GenericGesturesModality
{
    public class Options
    {

        private static Options instance = null;
        public static Options Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Options();
                }
                return instance;
            }
        }


        private Options()
        {
            try
            {
                dynamic o = JsonConvert.DeserializeObject(File.ReadAllText("conf.json"));
                address = o.address;
                port=o.port;
                Uid = o.Uid;

            }
            catch(Exception ex)
            {
                MessageBox.Show("Error loading configuration File, default values are: localhost/8000/User1");
                address = "localhost";
                port = 8000;
                Uid = "User1";
            }
        }

        public string address { get; set; }
        public int port { get; set; }
        public string Uid { get; set; }

    }
}
