﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Xml;
using Microsoft.Kinect;
using Microsoft.Kinect.VisualGestureBuilder;
using mmisharp;

namespace GenericGesturesModality
{
    public class GestureDetector : IDisposable
    {
        private LifeCycleEvents lce;
        private MmiCommunication mmic;

        /// <summary> Gesture database that was trained with Visual Gesture Builder</summary>
        private readonly string gestureDatabase = "Gestures.gbd";

        // Gesture frame source which should be tied to a body tracking ID
        private VisualGestureBuilderFrameSource vgbFrameSource = null;

        // Gesture frame reader which will handle gesture events coming from the sensor
        private VisualGestureBuilderFrameReader vgbFrameReader = null;

        // Flag resetable for discrete gesture results
        private bool flag = true;

        // Counter for continuous gesture results
        private int count;

        // Gestures names
        private List<string> gestName = new List<string>();

        // Initializes a new instance of the GestureDetector class along with the gesture frame source and reader
        public GestureDetector(KinectSensor kinectSensor, GestureResultView gestureResultView)
        {
            //init LifeCycleEvents..
            lce = new LifeCycleEvents("GESTURES", "FUSION", "gestures-1", "gestures", "command"); // LifeCycleEvents(string source, string target, string id, string medium, string mode)
            //mmic = new MmiCommunication("localhost",9876,"User1", "ASR");  //PORT TO FUSION - uncomment this line to work with fusion later
            mmic = new MmiCommunication(Options.Instance.address, Options.Instance.port, Options.Instance.Uid, "GESTURES"); // MmiCommunication(string IMhost, int portIM, string UserOD, string thisModalityName)
            mmic.Send(lce.NewContextRequest());
            count = 0;

            if (kinectSensor == null)
            {
                throw new ArgumentNullException("Kinect Sensor is null");
            }

            if (gestureResultView == null)
            {
                throw new ArgumentNullException("Gesture Result View is null");
            }

            GestureResultView = gestureResultView;

            // Create the vgb source. The associated body tracking ID will be set when a valid body frame arrives from the sensor.
            vgbFrameSource = new VisualGestureBuilderFrameSource(kinectSensor, 0);
            vgbFrameSource.TrackingIdLost += Source_TrackingIdLost;

            // Open the reader for the vgb frames
            vgbFrameReader = vgbFrameSource.OpenReader();
            if (vgbFrameReader != null)
            {
                vgbFrameReader.IsPaused = true;
                vgbFrameReader.FrameArrived += Reader_GestureFrameArrived;
            }

            /*
            // Path to the "Repository" directory where the gestures videos are stored
            DirectoryInfo d = new DirectoryInfo(Directory.GetParent(Directory.GetParent(Directory.GetParent(Directory.GetParent(Directory.GetCurrentDirectory()).ToString()).ToString()).ToString()).ToString() + "\\Repository");
            FileInfo[] Files = d.GetFiles("*.a.vgbproj");
            string str = "";
            int i = 0;
            string s;

            
            foreach (FileInfo file in Files)
            {
                str = str + " " + file.Name;
                s = file.ToString();
                gestName.Add(s.Substring(0, s.Length - 10));
                i++;
            }
            */



            // Load gestures from database
            using (VisualGestureBuilderDatabase database = new VisualGestureBuilderDatabase(gestureDatabase))
            {

                foreach (Gesture gesture in database.AvailableGestures)
                {
                    gestName.Add(gesture.Name);
                }

                int j = 0;
                foreach (Gesture gesture in database.AvailableGestures)
                {
                    if (gesture.Name.Equals(gestName[j]))
                    {
                        vgbFrameSource.AddGesture(gesture);
                    }
                    j++;
                }
            }

            WriteToXML();
            
        }

        // Get GestureResultView object which stores the detector results for display in the UI
        public GestureResultView GestureResultView { get; private set; }

        /*  Get or set the body tracking ID associated with the current detector
            The tracking ID can change whenever a body comes in/out of scope */
        public ulong TrackingId
        {
            get
            {
                return vgbFrameSource.TrackingId;
            }

            set
            {
                if (vgbFrameSource.TrackingId != value)
                {
                    vgbFrameSource.TrackingId = value;
                }
            }
        }

        /*  Get or set a value indicating whether or not the detector is currently paused
            If the body tracking ID associated with the detector is not valid, then the detector should be paused */
        public bool IsPaused
        {
            get
            {
                return vgbFrameReader.IsPaused;
            }

            set
            {
                if (vgbFrameReader.IsPaused != value)
                {
                    vgbFrameReader.IsPaused = value;
                }
            }
        }

        // Disposes all unmanaged resources for the class
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // Dispose the VisualGestureBuilderFrameSource and VisualGestureBuilderFrameReader objects
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (vgbFrameReader != null)
                {
                    vgbFrameReader.FrameArrived -= Reader_GestureFrameArrived;
                    vgbFrameReader.Dispose();
                    vgbFrameReader = null;
                }

                if (vgbFrameSource != null)
                {
                    vgbFrameSource.TrackingIdLost -= Source_TrackingIdLost;
                    vgbFrameSource.Dispose();
                    vgbFrameSource = null;
                }
            }
        }

        // Handles gesture detection results arriving from the sensor for the associated body tracking Id
        private void Reader_GestureFrameArrived(object sender, VisualGestureBuilderFrameArrivedEventArgs e)
        {
            using (var frame = e.FrameReference.AcquireFrame())
            {
                bool anyGestureDetected = false;
                float progress = 0;
                double sendConfidence = -1;

                if (frame != null)
                {
                    if (vgbFrameSource.IsTrackingIdValid)
                    {
                        // Get the discrete gesture results which arrived with the latest frame
                        IReadOnlyDictionary<Gesture, DiscreteGestureResult> discreteResults = frame.DiscreteGestureResults;
                        // Get the continuous gesture results which arrived with the latest frame
                        IReadOnlyDictionary<Gesture, ContinuousGestureResult> continuousResults = frame.ContinuousGestureResults;

                        if (Resetable(discreteResults))
                            flag = true;

                        if (discreteResults != null)
                        {
                            string sendGestureName = null;
                            //double sendConfidence = -1;

                            int i = 0;
                            foreach (Gesture gesture in this.vgbFrameSource.Gestures)
                            {
                                if (gesture.Name.Equals(gestName[i]) && gesture.GestureType == GestureType.Discrete)
                                {
                                    DiscreteGestureResult result = null;
                                    discreteResults.TryGetValue(gesture, out result);

                                    if (result != null)
                                    {
                                        Tuple<string, double> tuple = ProcessDiscreteGesture(result, gesture.Name);

                                        double confidence = tuple.Item2;
                                        if (confidence > sendConfidence)
                                        {
                                            sendGestureName = tuple.Item1;
                                            sendConfidence = tuple.Item2;
                                        }
                                    }
                                }
                                i++;
                            }

                            if (sendGestureName != null)
                            {
                                if (flag)
                                {
                                    int id;
                                    id = SendGestureID(sendGestureName);
                                    Console.WriteLine("Discrete gesture detected: ID " + id + " " + sendGestureName + " " + sendConfidence);
                                    SendMessage(id, getSemanatic(sendGestureName), sendConfidence);
                                    flag = false;
                                    anyGestureDetected = false;

                                    GestureResultView.setGesture(sendGestureName);
                                }

                            }
                        }

                        if (continuousResults != null)
                        {
                            int i = 0;
                            foreach (Gesture gesture in this.vgbFrameSource.Gestures)
                            {
                                if (gesture.Name.Equals(gestName[i]) && gesture.GestureType == GestureType.Continuous)
                                {
                                    ContinuousGestureResult result = null;
                                    continuousResults.TryGetValue(gesture, out result);

                                    if (result != null)
                                    {
                                        progress = result.Progress;

                                        if (progress >= 1)
                                        {
                                            count++;
                                            if (count != 15)
                                            {
                                                return;
                                            }
                                            count = 0;

                                            if (gesture.Name.Equals(gestName[i]))
                                            {
                                                int id;
                                                id = SendGestureID(gestName[i]);
                                                Console.WriteLine("Continuous gesture detected: ID " + id + " " + gestName[i] + " " + progress);
                                                SendMessage(id, getSemanatic(gestName[i]), progress);
                                                anyGestureDetected = true;
                                                GestureResultView.setGesture(gestName[i] + "->" + progress);
                                            }
                                        }
                                    }
                                    i++;
                                }
                            }
                        }
                    }
                    GestureResultView.UpdateGestureResult(true, anyGestureDetected, (float)sendConfidence);
                    Console.WriteLine(sendConfidence);
                }
            }
        }

        private Tuple<string, double> ProcessDiscreteGesture(DiscreteGestureResult detected, string gestureName)
        {
            int i = 0;
            foreach (string s in gestName)
            {
                if (gestureName.Equals(gestName[i]) && detected.Confidence > 0.70)
                {
                    return Tuple.Create<string, double>(gestureName, detected.Confidence);
                }
                i++;
            }

            return Tuple.Create<string, double>(null, -1);

        }

        public int SendGestureID(string gestureName)
        {
            int id = -1;
            int i = 0;
            foreach (string s in gestName)
            {
                if (gestureName.Equals(gestName[i]))
                {
                    id = i;
                    return id;
                }
                i++;
            }

            return id;
        }

        // Handle the TrackingIdLost event for the VisualGestureBuilderSource object
        private void Source_TrackingIdLost(object sender, TrackingIdLostEventArgs e)
        {
            // Update the GestureResultView object to show the 'Not Tracked' image in the UI
            GestureResultView.UpdateGestureResult(false, false, 0.0f);
        }

        private bool Resetable(IReadOnlyDictionary<Gesture, DiscreteGestureResult> arg)
        {
            bool response = true;
            foreach (Gesture gesture in this.vgbFrameSource.Gestures)
            {
                DiscreteGestureResult result = null;
                arg.TryGetValue(gesture, out result);
                if (result.Detected)
                    response = false;
            }
            return response;
        }

        // Send JSON message indicating the parameters in use
        private void SendMessage(int id, string gesture, double confidence)
        {
            string json = "{ \"recognized\": [";

            //json += "\"" + id + "\", ";
            json += "\"GESTURES\", ";
            json += "\"" + gesture.ToUpper() + "\"";
            

            //json = json.Substring(0, json.Length - 2);
            json += "], \"confidence\": \""+confidence+"\"  }";

            var exNot = lce.ExtensionNotification("", "", 1, json);
            mmic.Send(exNot);
        }

        private void WriteToXML()
        {
            DirectoryInfo dir = new DirectoryInfo(Directory.GetCurrentDirectory());
            XmlDocument doc = new XmlDocument();
            XmlComment comment = doc.CreateComment("This XML file contains the gestures of the database.");
            XmlNode xmlNode = doc.CreateNode(XmlNodeType.XmlDeclaration, "", "");
            XmlElement rootElement = doc.CreateElement("Gestures");
            doc.AppendChild(rootElement);
            List<string> semanticGestName = new List<string>();
            int k = 0;

            for (k = 0; k < gestName.Count; k++)
            {
                // Create the <Gesture> Node
                XmlElement gesture = doc.CreateElement("Gesture");

                // Create the <idText> Node
                XmlElement id = doc.CreateElement("ID");
                XmlText idText = doc.CreateTextNode(Convert.ToString(k));
                id.AppendChild(idText);

                // Add the <ID> child node to the <Gesture> element
                gesture.AppendChild(id);

                // Create the <nameText> Node
                XmlElement name = doc.CreateElement("NAME");
                XmlText nameText = doc.CreateTextNode(gestName[k]);
                name.AppendChild(nameText);

                // Add the <NAME> child node to the <Gesture> element
                gesture.AppendChild(name);

                // Create the <semanticText> Node
                XmlElement semantic = doc.CreateElement("SEMANTIC");

                int i = 0;
                foreach (string s in gestName)
                {   
                    StringBuilder builder = new StringBuilder();
                    bool flag = false;
                    foreach (char c in s)
                    {
                        if (builder.Length == 0)
                            builder.Append(c);
                        else
                        {
                            if (Char.IsLower(c) && flag == false)
                                builder.Append(c);
                            if (Char.IsUpper(c))
                            {
                                builder.Append(c);
                                flag = true;
                            }
                        }
                    }
                    semanticGestName.Add(builder.ToString());
                    i++;
                }

                XmlText semanticText = doc.CreateTextNode(semanticGestName[k]);
                semantic.AppendChild(semanticText);
                
                // Add the <SEMANTIC> child node to the <Gesture> element
                gesture.AppendChild(semantic);

                // Add the <Gesture> node to the root.
                rootElement.AppendChild(gesture);
            }
            doc.InsertBefore(comment, rootElement);
            doc.Save("Gestures.xml");
        }

        private string getSemanatic(string s)
        {
            StringBuilder builder = new StringBuilder();
            bool flag = false;
            foreach (char c in s)
            {
                if (builder.Length == 0)
                    builder.Append(c);
                else
                {
                    if (Char.IsLower(c) && flag == false)
                        builder.Append(c);
                    if (Char.IsUpper(c))
                    {
                        builder.Append(c);
                        flag = true;
                    }
                }
            }
            return builder.ToString();
        }

    }
}